#!/usr/bin/env python

import pandas as pandas
from uszipcode import SearchEngine
import json
from uszipcode import Zipcode

def retrieveValidZipCode(x,y):
    """
    This is the second step for season dates inspection,
    if the season is formatted with names of months it will use
    the current year for the season, otherwise it will send an
    empty string back.
    """
    search = SearchEngine(simple_zipcode=True)
    result = search.by_coordinates(y, x, radius=100, returns=5)
    print(len(result))
    return result[0].zip_code

if __name__ == '__main__':


    df = pandas.read_csv('export-csv.csv')
    # Please note that Facebook URL, Twitter URL, update Time have been formatted by OpenRefine tool itself.
    df['zip'] = df['zip'].apply(retrieveValidZipCode)